---
name: 🗎 Blank Issue
about: A blank issue. For those who know what they are doing.
title: ''
labels: 
assignees: ''

---