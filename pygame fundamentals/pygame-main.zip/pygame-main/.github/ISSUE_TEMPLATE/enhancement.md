---
name: 💡 Enhancement
about: Suggest an idea to improve or add to Pygame!
title: ''
labels: enhancement
assignees: ''

---

**Description**

Describe your enhancement, as clearly as possible.